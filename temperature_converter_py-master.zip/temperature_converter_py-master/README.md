# Temperature Converter

**temperature_converter_py** is a simple temperature converter.
## Install
- `pip install temperature-converter-py`
## Import
`import temperature_converter_py`

## Functions

- `celsius_to_fahrenheit(temp_in_celsius)`: Receives a float value in Celsius and returns in Fahrenheit.

- `fahrenheit_to_celsius(temp_in_fahrenheit)`: Receives a float value in Fahrenheit and returns in Celsius.

- `celsius_to_kelvin(temp_in_celsius)`: Receives a float value in Celsius and returns in Kelvin.

- `kelvin_to_celsius(temp_in_kelvin)`: Receives a float value in Kelvin and returns in Celsius.

- `fahrenheit_to_kelvin(temp_in_fahrenheit)`: Receives a float value in Fahrenheit and returns in Kelvin.

- `kelvin_to_fahrenheit(temp_in_kelvin)`: Receives a float value in Kelvin and returns in Fahrenheit.
